#### PATTERN | XX | PARSER COMMAND-LINE ############################################################

from __future__ import absolute_import

from .__init__ import parse, commandline
commandline(parse)
